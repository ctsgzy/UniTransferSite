---
layout: default
title: Examples
slug: examples
lead: "The examples of bootstrap table."
---

{% markdown examples/note.md %}

{% markdown examples/basic.md %}

{% markdown examples/style.md %}

{% markdown examples/align.md %}

{% markdown examples/sort.md %}

{% markdown examples/format.md %}

{% markdown examples/hide-header.md %}

{% markdown examples/columns.md %}

{% markdown examples/card-view.md %}

{% markdown examples/select.md %}

{% markdown examples/toolbar.md %}

{% markdown examples/pagination.md %}

{% markdown examples/events.md %}

{% markdown examples/methods.md %}