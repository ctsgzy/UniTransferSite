# Pagination []({{ site.repo }}/blob/master/docs/_includes/examples/pagination.md)

---

## Client Side

The default side pagination of table is `client`. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="400" src="http://jsfiddle.net/wenyi/e3nk137y/42/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>