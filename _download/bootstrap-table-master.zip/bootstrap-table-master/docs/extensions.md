---
layout: default
title: Extensions
slug: extensions
lead: "The extensions of bootstrap table."
---

{% markdown extensions/editable.md %}