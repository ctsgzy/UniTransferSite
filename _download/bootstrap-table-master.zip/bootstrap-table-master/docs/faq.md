---
layout: default
title: FAQ
slug: faq
lead: "Frequently Asked Questions."
---

{% markdown faq/faq.md %}

---

### How can I support development of bootstrap-table?

All your ideas and feedback are very appreciated! Please feel free to open issues on github or send me email.

I'm also grateful for your donations:

<script data-gratipay-username="wenzhixin" data-gratipay-widget="button" src="//gttp.co/v1.js"></script>

Thank you!