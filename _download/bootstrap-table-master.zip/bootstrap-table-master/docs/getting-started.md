---
layout: default
title: Getting started
slug: getting-started
lead: "An overview of Bootstrap Table, how to download and use, basic templates, and more."
---

{% markdown getting-started/download.md %}

{% markdown getting-started/whats-include.md %}

{% markdown getting-started/grunt.md %}

{% markdown getting-started/usage.md %}

{% markdown getting-started/translations.md %}